from setuptools import setup

setup(name='ads',
    version='0.1',
    description='ads',
    url='https://github.com/li-lu/bd',
    author='li-lu',
    author_email='li_lu2000@hotmail.com',
    license='MIT',
    packages=['ads'],
    install_requires=[
        'markdown',
    ],
    zip_safe=False)
